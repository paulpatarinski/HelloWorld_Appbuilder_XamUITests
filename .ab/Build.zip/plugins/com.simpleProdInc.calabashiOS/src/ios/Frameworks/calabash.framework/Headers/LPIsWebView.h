#import <UIKit/UIKit.h>

@interface LPIsWebView : NSObject

+ (BOOL) isWebView:(id) object;

@end

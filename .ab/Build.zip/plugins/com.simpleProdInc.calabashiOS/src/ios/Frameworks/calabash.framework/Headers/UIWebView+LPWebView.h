#import <UIKit/UIKit.h>
#import "LPWebViewProtocol.h"

@interface UIWebView (UIWebView_LPWebView) <LPWebViewProtocol>

@end
